define('app',["exports", "./phaser/main"], function (_exports, _main) {
  "use strict";

  _exports.__esModule = true;
  _exports.App = void 0;

  var App =
  /*#__PURE__*/
  function () {
    function App() {}

    var _proto = App.prototype;

    _proto.attached = function attached() {
      FBInstant.initializeAsync().then(function () {
        new _main.PhaserMain().go();
      });
    };

    return App;
  }();

  _exports.App = App;
});;
define('text!app.css',[],function(){return ".message {\n\tposition: absolute;\n\twidth: 100%;\n\ttext-align: center;\n}\n";});;
define('text!app.html',[],function(){return "<template>\n\t<require from=\"./app.css\"></require>\n  \t<div id=\"game\"></div>\n</template>\n";});;
define('environment',["exports"], function (_exports) {
  "use strict";

  _exports.__esModule = true;
  _exports.default = void 0;
  var _default = {
    debug: true,
    testing: true
  };
  _exports.default = _default;
});;
define('main',["exports", "./environment"], function (_exports, _environment) {
  "use strict";

  _exports.__esModule = true;
  _exports.configure = configure;
  _environment = _interopRequireDefault(_environment);

  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

  function configure(aurelia) {
    aurelia.use.standardConfiguration().feature('resources');
    aurelia.use.developmentLogging(_environment.default.debug ? 'debug' : 'warn');

    if (_environment.default.testing) {
      aurelia.use.plugin('aurelia-testing');
    }

    return aurelia.start().then(function () {
      return aurelia.setRoot();
    });
  }
});;
define('phaser/config',["exports", "./scenes/loaderscene", "./scenes/gamescene"], function (_exports, _loaderscene, _gamescene) {
  "use strict";

  _exports.__esModule = true;
  _exports.config = void 0;
  var config = {
    type: Phaser.AUTO,
    parent: 'game',
    width: window.innerWidth,
    height: window.innerHeight,
    physics: {
      default: 'arcade',
      arcade: {
        debug: true
      }
    },
    scale: {
      mode: Phaser.DOM.ENVELOP,
      width: window.innerWidth,
      height: window.innerHeight,
      autoCenter: Phaser.DOM.CENTER_BOTH
    },
    backgroundColor: '#CC8899',
    scene: [_loaderscene.LoaderScene, _gamescene.GameScene]
  };
  _exports.config = config;
});;
define('phaser/main',["exports", "phaser", "./config"], function (_exports, _phaser, _config) {
  "use strict";

  _exports.__esModule = true;
  _exports.PhaserMain = void 0;
  _phaser = _interopRequireDefault(_phaser);

  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

  var PhaserMain =
  /*#__PURE__*/
  function () {
    function PhaserMain() {}

    var _proto = PhaserMain.prototype;

    _proto.go = function go() {
      return new _phaser.default.Game(_config.config);
    };

    return PhaserMain;
  }();

  _exports.PhaserMain = PhaserMain;
});;
define('phaser/scenes/gamescene',["exports", "phaser", "../util/eggs"], function (_exports, _phaser, _eggs) {
  "use strict";

  _exports.__esModule = true;
  _exports.GameScene = void 0;

  function _inheritsLoose(subClass, superClass) { subClass.prototype = Object.create(superClass.prototype); subClass.prototype.constructor = subClass; subClass.__proto__ = superClass; }

  var GameScene =
  /*#__PURE__*/
  function (_Scene) {
    _inheritsLoose(GameScene, _Scene);

    function GameScene() {
      return _Scene.call(this, {
        key: 'GameScene'
      }) || this;
    }

    var _proto = GameScene.prototype;

    _proto.create = function create() {
      /* INITS */
      this.capacity = 6;
      this.eggsOnScreen = 0;
      this.eggs = {}; //setInterval(() => { console.log(this.eggs) }, 1000);

      this.addBg();
      this.dragHandler();
      this.startEggSpawner();
    };

    _proto.addBg = function addBg() {
      this.add.image(this.game.config.width / 2, this.game.config.height / 2, 'grassBg').setOrigin(0.5, 0.5);
    };

    _proto.dragHandler = function dragHandler() {
      var _this = this;

      this.input.on('drag', function (pointer, gameObject, dragX, dragY) {
        gameObject.x = dragX;
        gameObject.y = dragY;
      });
      this.input.on('dragend', function (pointer, gameObject, dragX, dragY) {
        _this.checkForOverlaps(gameObject);
      });
    };

    _proto.startEggSpawner = function startEggSpawner() {
      var _this2 = this;

      this.time.addEvent({
        delay: 500,
        loop: true,
        callbackScope: this,
        callback: function callback() {
          if (_this2.eggsOnScreen < _this2.capacity) _this2.placeEgg('yellow');
        }
      });
    };

    _proto.placeEgg = function placeEgg(type, x, y) {
      var uuid = _phaser.Math.RND.uuid();

      var destX = x || _phaser.Math.RND.between(50, this.game.config.width - 50);

      var destY = y || _phaser.Math.RND.between(50, this.game.config.height - 50);

      var egg = this.add.image(destX, destY, type).setScale(0.25, 0.25);
      egg.uuid = uuid;
      egg.type = type;
      egg.alpha = 0;
      this.spawnTween(egg);
      this.eggs[uuid] = egg;
      this.eggsOnScreen++;
    };

    _proto.checkForOverlaps = function checkForOverlaps(egg) {
      var eggs = Object.values(this.eggs);

      for (var i = 0; i < eggs.length; i++) {
        if (egg.uuid !== eggs[i].uuid) {
          var eBounds = egg.getBounds();
          var tBounds = eggs[i].getBounds();
          var intersects = Phaser.Geom.Intersects.RectangleToRectangle(eBounds, tBounds);

          if (intersects) {
            console.log('Trying to combine...');
            this.tryCombine(egg, eggs[i]);
            break;
          }
        }
      }
    };

    _proto.tryCombine = function tryCombine(eggA, eggB) {
      var newTypePosA = _eggs.eggRecipes[eggA.type + eggB.type];
      var newTypePosB = _eggs.eggRecipes[eggB.type + eggA.type];
      var newType = newTypePosA || newTypePosB;

      if (newType) {
        this.combineEggs(eggA, eggB, newType);
      } else {
        this.rejectEggs(eggA, eggB);
      }
    };

    _proto.combineEggs = function combineEggs(eggA, eggB, newType) {
      if (!eggA.combining && !eggB.combining) {
        eggA.combining = true;
        eggB.combining = true;
        this.combineTween(eggA, eggB, newType);
      }
    };

    _proto.rejectEggs = function rejectEggs(eggA, eggB) {
      var target = _phaser.Math.RND.pick([eggA, eggB]);

      var axis = _phaser.Math.RND.pick(['x', 'y']);

      var current = target[axis];
      var bound = axis === 'x' ? this.game.config.width : this.game.config.height;
      var dest;

      if (current + 100 > bound) {
        dest = current - 50;
      } else if (current - 100 > 0) {
        dest = current + 50;
      } else {
        dest = current + 50;
      }

      var rejectTweenObj = {
        targets: target,
        duration: 1000,
        ease: 'Bounce.easeInOut',
        onComplete: function onComplete() {
          if (eggA) eggA.combining = false;
          if (eggB) eggB.combining = false;
        }
      };
      rejectTweenObj[axis] = dest;
      this.tweens.add(rejectTweenObj);
    };

    _proto.combineTween = function combineTween(eggA, eggB, newType) {
      var _this3 = this;

      delete this.eggs[eggA.uuid];
      delete this.eggs[eggB.uuid];

      var target = _phaser.Math.RND.pick([eggA, eggB]);

      var newLoc = {
        x: target.x,
        y: target.y
      };
      this.tweens.add({
        targets: [eggA, eggB],
        x: newLoc.x,
        y: newLoc.y,
        ease: 'Bounce.easeInOut',
        duration: 1000,
        onComplete: function onComplete() {
          _this3.destroyTween(eggA, eggB, newType, newLoc);
        }
      });
    };

    _proto.destroyTween = function destroyTween(eggA, eggB, newType, newLoc) {
      var _this4 = this;

      this.tweens.add({
        targets: [eggA, eggB],
        alpha: 0,
        duration: 500,
        onComplete: function onComplete() {
          if (eggA) eggA.destroy();
          if (eggB) eggB.destroy();

          _this4.placeEgg(newType, newLoc.x, newLoc.y);
        }
      });
    };

    _proto.spawnTween = function spawnTween(egg) {
      var _this5 = this;

      /* BREATHE */
      this.tweens.add({
        targets: egg,
        scaleX: 0.30,
        yoyo: true,
        duration: 500,
        repeat: -1
      });
      /* TILT */

      this.tweens.add({
        targets: egg,
        rotation: 0.25,
        duration: 750,
        repeat: -1,
        yoyo: true
      });
      /* FADE IN */

      this.tweens.add({
        targets: egg,
        alpha: 1.00,
        duration: 750,
        onComplete: function onComplete() {
          _this5.enableEgg(egg);
        }
      });
    };

    _proto.enableEgg = function enableEgg(egg) {
      egg.setInteractive();
      this.input.setDraggable(egg);
    };

    return GameScene;
  }(_phaser.Scene);

  _exports.GameScene = GameScene;
});;
define('phaser/scenes/loaderscene',["exports", "phaser"], function (_exports, _phaser) {
  "use strict";

  _exports.__esModule = true;
  _exports.LoaderScene = void 0;

  function _inheritsLoose(subClass, superClass) { subClass.prototype = Object.create(superClass.prototype); subClass.prototype.constructor = subClass; subClass.__proto__ = superClass; }

  var LoaderScene =
  /*#__PURE__*/
  function (_Scene) {
    _inheritsLoose(LoaderScene, _Scene);

    function LoaderScene() {
      return _Scene.call(this, {
        key: 'LoaderScene'
      }) || this;
    }

    var _proto = LoaderScene.prototype;

    _proto.preload = function preload() {
      this.facebook.once('startgame', this.start, this);
      this.facebook.showLoadProgress(this);
      this.load.image('grassBg', 'src/assets/grass.png');
      this.load.image('yellow', 'src/assets/yellow.png');
      this.load.image('pink', 'src/assets/pink.png');
      this.load.image('purple', 'src/assets/purple.png');
      this.load.image('brown', 'src/assets/brown.png');
    };

    _proto.start = function start() {
      this.scene.start('GameScene');
    };

    return LoaderScene;
  }(_phaser.Scene);

  _exports.LoaderScene = LoaderScene;
});;
define('phaser/sprites/phaserhello',["exports", "phaser"], function (_exports, _phaser) {
  "use strict";

  _exports.__esModule = true;
  _exports.PhaserHello = void 0;

  function _inheritsLoose(subClass, superClass) { subClass.prototype = Object.create(superClass.prototype); subClass.prototype.constructor = subClass; subClass.__proto__ = superClass; }

  var PhaserHello =
  /*#__PURE__*/
  function (_GameObjects$Sprite) {
    _inheritsLoose(PhaserHello, _GameObjects$Sprite);

    function PhaserHello(scene, x, y, key) {
      var _this;

      _this = _GameObjects$Sprite.call(this, scene, x, y, key) || this;

      _this.add();

      return _this;
    }

    var _proto = PhaserHello.prototype;

    _proto.update = function update() {
      if (this.body.x <= 0) {
        this.body.setVelocityX(400);
      }

      if (this.body.x >= this.scene.game.config.width - this.width) {
        this.body.setVelocityX(-400);
      }
    };

    _proto.add = function add() {
      this.scene.add.existing(this);
      this.scene.physics.world.enable(this);
      this.body.setVelocityX(-400);
    };

    return PhaserHello;
  }(_phaser.GameObjects.Sprite);

  _exports.PhaserHello = PhaserHello;
});;
define('phaser/util/eggs',["exports"], function (_exports) {
  "use strict";

  _exports.__esModule = true;
  _exports.eggRecipes = _exports.eggs = void 0;
  var eggs = ['yellow', 'pink', 'purple', 'brown'];
  _exports.eggs = eggs;
  var eggRecipes = {
    'yellowyellow': 'pink',
    'pinkyellow': 'brown',
    'pinkpink': 'purple'
  };
  _exports.eggRecipes = eggRecipes;
});;
define('resources/index',["exports"], function (_exports) {
  "use strict";

  _exports.__esModule = true;
  _exports.configure = configure;

  function configure(config) {//config.globalResources([]);
  }
});;
define('resources',['resources/index'],function(m){return m;});
//# sourceMappingURL=app-bundle.js.map