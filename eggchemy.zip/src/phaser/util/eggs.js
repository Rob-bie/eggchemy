export const eggs = [
	'yellow',
	'pink',
	'purple',
	'brown'
];

export const eggRecipes = {
	'yellowyellow': 'pink',
	'pinkyellow': 'brown',
	'pinkpink': 'purple'
}
